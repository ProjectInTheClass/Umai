const express = require('express');
const router = express.Router();
const Restaurant = require('../models/Restaurant');

// Get all restaurants
router.get('/', async (req, res) => {
    try {
        const restaurants = await Restaurant.findAll();
        res.json(restaurants);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch restaurants' });
    }
});

// Get a single restaurant by ID
router.get('/:id', async (req, res) => {
    try {
        const restaurant = await Restaurant.findByPk(req.params.id);
        if (restaurant) {
            res.json(restaurant);
        } else {
            res.status(404).json({ error: 'Restaurant not found' });
        }
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch restaurant' });
    }
});

// Create a new restaurant
router.post('/', async (req, res) => {
    try {
        const { name, location, menu, description } = req.body;
        const newRestaurant = await Restaurant.create({ name, location, menu, description });
        res.status(201).json(newRestaurant);
    } catch (err) {
        res.status(500).json({ error: 'Failed to create restaurant' });
    }
});

// Update a restaurant
router.put('/:id', async (req, res) => {
    try {
        const { name, location, menu, description } = req.body;
        const restaurant = await Restaurant.findByPk(req.params.id);
        if (restaurant) {
            await restaurant.update({ name, location, menu, description });
            res.json(restaurant);
        } else {
            res.status(404).json({ error: 'Restaurant not found' });
        }
    } catch (err) {
        res.status(500).json({ error: 'Failed to update restaurant' });
    }
});

// Delete a restaurant
router.delete('/:id', async (req, res) => {
    try {
        const restaurant = await Restaurant.findByPk(req.params.id);
        if (restaurant) {
            await restaurant.destroy();
            res.json({ message: 'Restaurant deleted successfully' });
        } else {
            res.status(404).json({ error: 'Restaurant not found' });
        }
    } catch (err) {
        res.status(500).json({ error: 'Failed to delete restaurant' });
    }
});

module.exports = router;