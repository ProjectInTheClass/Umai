const express = require('express');
const cors = require('cors');
const app = express();
const Restaurant = require('./models/Restaurant');

// Middleware
app.use(cors());
app.use(express.json()); // Support JSON requests

// Routes
app.use('/api/restaurants', require('./routers/restaurant'));

// Default Route
app.get('/', async (req, res) => {
    try {
        const restaurants = await Restaurant.findAll();
        res.json(restaurants);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch data' });
    }
});

const PORT = 3333;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));